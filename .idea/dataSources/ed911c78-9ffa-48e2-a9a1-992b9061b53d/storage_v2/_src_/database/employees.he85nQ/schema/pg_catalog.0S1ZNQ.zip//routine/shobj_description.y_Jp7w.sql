create function shobj_description(oid, name) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function shobj_description(oid, name) is 'get description for object id and shared catalog name';

alter function shobj_description(oid, name) owner to postgres;

